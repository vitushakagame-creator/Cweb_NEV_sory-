@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Cweb CMD — сборка и запуск
where dotnet >nul 2>&1
if errorlevel 1 (
  echo Не найден .NET 8 SDK. Установите SDK: https://dotnet.microsoft.com/download/dotnet/8.0
  start "" "https://dotnet.microsoft.com/download/dotnet/8.0"
  pause
  exit /b 1
)
echo Сборка Cweb CMD...
dotnet publish "CwebCmd\CwebCmd.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "dist"
if errorlevel 1 (
  echo Ошибка сборки. Проверьте сообщение выше.
  pause
  exit /b 1
)
echo.
echo Готово. Запускаю консольную программу...
"dist\CwebCMD.exe"
pause
