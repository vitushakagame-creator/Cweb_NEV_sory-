using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace CwebCMD;

internal static class Program
{
    private static readonly string Root = AppContext.BaseDirectory;
    private static readonly Dictionary<string, ConsoleColor> Colors = new(StringComparer.OrdinalIgnoreCase)
    {
        ["black"] = ConsoleColor.Black, ["blue"] = ConsoleColor.Blue, ["cyan"] = ConsoleColor.Cyan,
        ["green"] = ConsoleColor.Green, ["magenta"] = ConsoleColor.Magenta, ["red"] = ConsoleColor.Red,
        ["white"] = ConsoleColor.White, ["yellow"] = ConsoleColor.Yellow, ["gray"] = ConsoleColor.Gray,
        ["grey"] = ConsoleColor.Gray, ["darkblue"] = ConsoleColor.DarkBlue, ["darkcyan"] = ConsoleColor.DarkCyan,
        ["darkgreen"] = ConsoleColor.DarkGreen, ["darkmagenta"] = ConsoleColor.DarkMagenta,
        ["darkred"] = ConsoleColor.DarkRed, ["darkyellow"] = ConsoleColor.DarkYellow
    };

    private static int Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        Console.Title = "Cweb CMD — консольная среда";
        Header();
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Cweb> ");
            Console.ResetColor();
            string? input = Console.ReadLine();
            if (input is null) break;
            string line = input.Trim();
            if (line.Length == 0) continue;
            string command = FirstWord(line).ToLowerInvariant();
            string args = line.Length > FirstWord(line).Length ? line[FirstWord(line).Length..].Trim() : "";
            try
            {
                switch (command)
                {
                    case "exit": case "quit": return 0;
                    case "help": case "?": ShowHelp(); break;
                    case "cls": case "clear": Console.Clear(); Header(); break;
                    case "color": case "цвет": SetColor(args); break;
                    case "start": CreateFileFlow(); break;
                    case "stop": StopFlow(); break;
                    case "ftl": EditFileFlow(args); break;
                    case "run": RunFile(args); break;
                    case "in": ImportCommand(args); break;
                    case "import": Console.WriteLine("Для команды import обязательно напишите перед ней in: in import <файл>"); break;
                    case "pwd": Console.WriteLine(Environment.CurrentDirectory); break;
                    case "dir": ListFiles(args); break;
                    case "cd": ChangeDirectory(args); break;
                    case "version": Console.WriteLine("Cweb CMD 1.0"); break;
                    default: Console.WriteLine($"Неизвестная команда: {command}. Напишите Help."); break;
                }
            }
            catch (Exception ex) { Console.WriteLine("Ошибка: " + ex.Message); }
        }
        return 0;
    }

    private static string FirstWord(string s) => s.Split((char[]?)null, 2, StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";

    private static void Header()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("============================================================");
        Console.WriteLine(" CWEB CMD 1.0  |  Help  |  Start  |  Stop  |  FTL  |  Run");
        Console.WriteLine("============================================================");
        Console.ResetColor();
        Console.WriteLine("Командная версия Cweb. Напишите Help для списка команд.");
        Console.WriteLine($"Рабочая папка: {Environment.CurrentDirectory}");
        Console.WriteLine();
    }

    private static void ShowHelp()
    {
        Console.WriteLine("\nКОМАНДЫ CWEB CMD (справка на русском)");
        Console.WriteLine("  Help                         — показать эту справку");
        Console.WriteLine("  Start                        — создать новый файл в редакторе");
        Console.WriteLine("  Ctrl+Enter                   — сохранить файл в редакторе в текущей папке");
        Console.WriteLine("  Stop                         — завершить ввод, затем указать папку и имя файла");
        Console.WriteLine("  FTL <путь> <имя-файла>       — открыть файл для изменения; сохранение перезапишет его");
        Console.WriteLine("  Run <путь-к-файлу>           — запустить .exe/.bat/.cmd или выполнить .cweb");
        Console.WriteLine("  in import <путь-к-файлу>     — загрузить и показать текст файла");
        Console.WriteLine("  color <цвет>                 — сменить цвет консоли (green, blue, red, yellow...)");
        Console.WriteLine("  dir [путь]                   — показать файлы и папки");
        Console.WriteLine("  cd <путь>                    — сменить рабочую папку");
        Console.WriteLine("  pwd                          — показать текущую папку");
        Console.WriteLine("  cls                          — очистить экран");
        Console.WriteLine("  version                      — версия программы");
        Console.WriteLine("  exit                         — выйти");
        Console.WriteLine("\nВ редакторе вводите текст как обычно, пробелы и пустые строки сохраняются.");
        Console.WriteLine("В FTL сначала укажите путь к папке, затем имя файла. Пути с пробелами берите в кавычки.");
        Console.WriteLine("Пример: FTL \"C:\\Users\\Me\\Desktop\" notes.txt\n");
    }

    private static void SetColor(string value)
    {
        string name = value.Trim().Trim('"');
        if (!Colors.TryGetValue(name, out var color))
        {
            Console.WriteLine("Неизвестный цвет. Примеры: green, blue, red, yellow, cyan, white, magenta, gray.");
            return;
        }
        Console.ForegroundColor = color;
        Console.WriteLine("Цвет текста изменён на " + name + ".");
        Console.ResetColor();
        Console.ForegroundColor = color;
    }

    private static void CreateFileFlow()
    {
        Console.WriteLine("Редактор нового файла. Ctrl+Enter — сохранить здесь; Esc — отменить.");
        string? text = ReadEditor("");
        if (text is null) { Console.WriteLine("Создание отменено."); return; }
        Console.Write("Имя нового файла (например, notes.txt): ");
        string? name = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(name)) { Console.WriteLine("Имя файла не указано."); return; }
        string path = Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, name.Trim().Trim('"')));
        File.WriteAllText(path, text, new UTF8Encoding(false));
        Console.WriteLine("Создан файл: " + path);
    }

    private static void StopFlow()
    {
        Console.WriteLine("Режим ввода текста. Напишите строки; отдельная строка .END завершает ввод.");
        Console.WriteLine("После этого укажите путь к папке и имя файла.");
        var lines = new List<string>();
        while (true)
        {
            string? line = Console.ReadLine();
            if (line is null || line == ".END") break;
            lines.Add(line);
        }
        Console.Write("Путь к папке (Enter = текущая): ");
        string folder = Console.ReadLine()?.Trim().Trim('"') ?? "";
        if (folder.Length == 0) folder = Environment.CurrentDirectory;
        Console.Write("Имя файла: ");
        string? name = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(name)) { Console.WriteLine("Имя файла не указано."); return; }
        Directory.CreateDirectory(folder);
        string path = Path.GetFullPath(Path.Combine(folder, name.Trim().Trim('"')));
        File.WriteAllText(path, string.Join(Environment.NewLine, lines), new UTF8Encoding(false));
        Console.WriteLine("Файл сохранён: " + path);
    }

    private static string? ReadEditor(string initial)
    {
        var buffer = new StringBuilder(initial);
        Console.WriteLine("---------------- РЕДАКТОР ----------------");
        if (initial.Length > 0) Console.Write(initial);
        while (true)
        {
            var key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.Escape) { Console.WriteLine("\nОтменено."); return null; }
            if (key.Key == ConsoleKey.Enter && key.Modifiers.HasFlag(ConsoleModifiers.Control))
            {
                Console.WriteLine("\nСохранение...");
                return buffer.ToString();
            }
            if (key.Key == ConsoleKey.Enter)
            {
                buffer.AppendLine(); Console.WriteLine(); continue;
            }
            if (key.Key == ConsoleKey.Backspace)
            {
                if (buffer.Length > 0)
                {
                    buffer.Length--;
                    if (Console.CursorLeft > 0) { Console.Write("\b \b"); }
                }
                continue;
            }
            if (key.Key == ConsoleKey.Tab) { buffer.Append("\t"); Console.Write("    "); continue; }
            if (!char.IsControl(key.KeyChar)) { buffer.Append(key.KeyChar); Console.Write(key.KeyChar); }
        }
    }

    private static void EditFileFlow(string args)
    {
        if (string.IsNullOrWhiteSpace(args))
        {
            Console.WriteLine("Формат: FTL <путь-к-папке> <имя-файла>");
            Console.WriteLine("Пример: FTL \"C:\\Users\\Me\\Desktop\" hello.txt"); return;
        }
        var parts = SplitArguments(args);
        if (parts.Count < 2) { Console.WriteLine("Укажите отдельно путь к папке и имя файла. Пути с пробелами берите в кавычки."); return; }
        string path = Path.GetFullPath(Path.Combine(parts[0], parts[1]));
        if (!File.Exists(path)) { Console.WriteLine("Файл не найден: " + path); return; }
        string original = File.ReadAllText(path);
        Console.WriteLine("Редактирование: " + path);
        Console.WriteLine("Ctrl+Enter — сохранить изменения; Esc — отменить.");
        string? updated = ReadEditor(original);
        if (updated is null) { Console.WriteLine("Изменения отменены."); return; }
        File.WriteAllText(path, updated, new UTF8Encoding(false));
        Console.WriteLine("Изменения сохранены: " + path);
    }

    private static List<string> SplitArguments(string input)
    {
        var matches = Regex.Matches(input, "\\\"([^\\\"]*)\\\"|(\\S+)");
        return matches.Select(m => m.Groups[1].Success ? m.Groups[1].Value : m.Groups[2].Value).ToList();
    }

    private static void ImportCommand(string args)
    {
        string rest = args.Trim();
        if (!rest.StartsWith("import", StringComparison.OrdinalIgnoreCase))
        { Console.WriteLine("Формат команды: in import <путь-к-файлу>"); return; }
        string target = rest[6..].Trim().Trim('"');
        if (target.Length == 0) { Console.WriteLine("Укажите файл: in import notes.txt"); return; }
        string path = Path.GetFullPath(target);
        if (!File.Exists(path)) { Console.WriteLine("Файл не найден: " + path); return; }
        Console.WriteLine($"--- Содержимое {path} ---");
        Console.WriteLine(File.ReadAllText(path));
        Console.WriteLine("--- конец файла ---");
    }

    private static void RunFile(string args)
    {
        string target = args.Trim().Trim('"');
        if (target.Length == 0) { Console.WriteLine("Формат: Run <путь-к-файлу>"); return; }
        string path = Path.GetFullPath(target);
        if (!File.Exists(path)) { Console.WriteLine("Файл не найден: " + path); return; }
        string ext = Path.GetExtension(path).ToLowerInvariant();
        if (ext == ".cweb") { ExecuteCweb(path); return; }
        if (ext is not ".exe" and not ".bat" and not ".cmd")
        { Console.WriteLine("Run поддерживает .exe, .bat, .cmd и .cweb."); return; }
        var psi = new ProcessStartInfo(path) { UseShellExecute = true, WorkingDirectory = Path.GetDirectoryName(path) ?? Environment.CurrentDirectory };
        Process.Start(psi);
        Console.WriteLine("Запуск выполнен: " + path);
    }

    private static void ExecuteCweb(string path)
    {
        Console.WriteLine("Выполнение Cweb: " + path);
        foreach (string raw in File.ReadLines(path))
        {
            string line = raw.Trim();
            if (line.Length == 0 || line.StartsWith("#")) continue;
            if (line.StartsWith("print(", StringComparison.OrdinalIgnoreCase))
            {
                int start = line.IndexOf('(') + 1, end = line.LastIndexOf(')');
                if (end >= start) Console.WriteLine(line[start..end].Trim().Trim('"', '\''));
            }
            else if (line.Equals("in import", StringComparison.OrdinalIgnoreCase) || line.StartsWith("in import ", StringComparison.OrdinalIgnoreCase))
                ImportCommand(line[2..]);
            else Console.WriteLine("[команда распознана как текст] " + line);
        }
    }

    private static void ListFiles(string args)
    {
        string dir = string.IsNullOrWhiteSpace(args) ? Environment.CurrentDirectory : Path.GetFullPath(args.Trim().Trim('"'));
        if (!Directory.Exists(dir)) { Console.WriteLine("Папка не найдена: " + dir); return; }
        foreach (string d in Directory.GetDirectories(dir)) Console.WriteLine("[ПАПКА] " + Path.GetFileName(d));
        foreach (string f in Directory.GetFiles(dir)) Console.WriteLine("         " + Path.GetFileName(f));
    }

    private static void ChangeDirectory(string args)
    {
        string dir = args.Trim().Trim('"');
        if (dir.Length == 0) { Console.WriteLine("Формат: cd <путь>"); return; }
        dir = Path.GetFullPath(dir);
        if (!Directory.Exists(dir)) { Console.WriteLine("Папка не найдена: " + dir); return; }
        Environment.CurrentDirectory = dir;
        Console.WriteLine("Текущая папка: " + dir);
    }
}
