@echo off
setlocal
cd /d "%~dp0"
title Cweb CMD - Build and Run
where dotnet >nul 2>&1
if errorlevel 1 (
  echo ERROR: .NET 8 SDK was not found.
  echo Install it from: https://dotnet.microsoft.com/download/dotnet/8.0
  start "" "https://dotnet.microsoft.com/download/dotnet/8.0"
  pause
  exit /b 1
)
echo Building Cweb CMD...
dotnet publish "CwebCmd\CwebCmd.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o "dist"
if errorlevel 1 (
  echo.
  echo ERROR: Build failed. Read the error messages above.
  pause
  exit /b 1
)
if not exist "dist\CwebCMD.exe" (
  echo ERROR: Build finished but dist\CwebCMD.exe was not found.
  pause
  exit /b 1
)
echo.
echo Build complete. Starting Cweb CMD...
start "Cweb CMD" /wait "%~dp0dist\CwebCMD.exe"
echo.
echo Cweb CMD has closed.
pause
endlocal
